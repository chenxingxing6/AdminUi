/**
 * account 用户
 */
var Account = {

    bindFancyBox: function() {

        
    }
};